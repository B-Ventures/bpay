<?php 
/*
Hernyo CMS
Very simple and lightweight flat file CMS
by Attila Gothard 
http://hernyo.com
https://demo.hernyo.com
https://client.hernyo.com

Copyright 2017 hernyo.com
*/

return array (
  'user' => 'username',
  'pass' => '$2y$15$mfRLqjhkVA9VSQY0DjdkeuJ5a/fXqWvXBkI9cUV0KdXaOjfzw1dI6',
  'db' => 'data.dat',
  'site_title' => 'Hernyo',
  'site_description' => 'Very simple and lightweight flat file CMS written in PHP and built with you in mind.',
  'site_keywords' => 'Hernyo, HernyoCMS, PHP, CMS, Simple, lightweight, small, easy, Minimal',
  'language' => 'en',
  'theme' => 'jumbtron2',
  'files_folder' => '../files',
);