<?php
/*
Hernyo CMS
Very simple and lightweight flat file CMS
by Attila Gothard 
http://hernyo.com
https://demo.hernyo.com
https://client.hernyo.com

Copyright 2017 hernyo.com
*/

// Start the CMS
define('HERNYO_FOLDER', 'admin/');
require_once HERNYO_FOLDER . 'hernyo.php';

?>
